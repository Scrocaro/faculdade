Usei alguns vídeos e sites na internet pra me basear pra implementar as funções.
Já o AVL eu não consegui fazer rodar direito, e iria pegar mt coisa da internet kkk então preferi nem mandar.

Mais um adendo: eu não estava conseguindo rodar o código por erros de falha de segmentação e só consegui resolver colocando {} em if's que tinham 
apenas 1 instrução, entendi nada... Devia ser isso que estava fazendo o código do meu trabalho bugar também, a gente tentou de tudo (menos colocar
essas chaves) pra arrumar as falhas no trabalho e não conseguimos, já que não faziamos ideia que podia ser isso.