void Arquivo_Dividir(char* teste, float k, float n_registros);


void troca(ITEM_VENDA* v, int maior, int i);
int partition(ITEM_VENDA* v, int p, int r);
void quickSort(ITEM_VENDA *v, int e, int d);
