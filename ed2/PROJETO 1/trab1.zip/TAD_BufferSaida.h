#include "big_file.h"
BUFFER* BufferSaida_Criar(float k);
void BufferSaida_Inserir(BUFFER* buffer, ITEM_VENDA iv_saida);
void BufferSaida_Despejar(BUFFER* buffer);
void BufferSaida_Destruir(BUFFER* buffer);