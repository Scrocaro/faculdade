#include <stdio.h>
#include <string.h>
#include "pilha.h"

int precedencia(char maior, char atual);
int tipografico(char atual);
int tipo_completa(char maior, char atual);
void checar_invalidez(char* x);

void flush_in(){
  int ch;
  do{
    ch = fgetc(stdin);
  }while (ch != EOF && ch != '\n');
}

/**********************************************************************/
/******************************** MAIN ********************************/
int main(){
  char x[100000];
  int tipo = 1, z=0;
  do{
    printf("Entre 1 e 20 - Quantos testes deseja realizar? ");
    scanf("%d", &z);
    flush_in();
  }while(z < 1 || z > 20);

  for(int i=0; i<z;i++){
    do{
      printf("[%d/%d] Entre 1 e 100.000 caracteres - Digite a cadeia de '{[()}}' que deseja testar: ", i+1, z);
      scanf("%s", x);
      flush_in();
      for(int i=0; i<strlen(x)-1; i++){
        if(tipografico(x[i]) == 0){
          tipo = 0;
          break;
        }
      }
    }while(strlen(x) < 1 || strlen(x) > 100000 || tipo == 0);
    checar_invalidez(x);
  }
  // strcpy(x, "[{[{}]}]");
  // checar_invalidez(x);
}

/**********************************************************************/
/************************** FUNÇÃO PRINCIPAL **************************/

void checar_invalidez(char* x){
  Pilha* p = pilha_criar();
  /**************************/
  /*****SEPARAR EM PILHA*****/
  for(int i=strlen(x)-1; i>=0; i--){ //Começa do final pro inicio e separa os sinais tipograficos
    if(tipografico(x[i]) == 1){
      pilha_push(p, x[i]);
    }
  }
  /**************************/
  /***CHECAR SE É INVALIDO***/
  Pilha* pclone = pilha_clone(p);
  No* tmp = pclone->topo;
  while(tmp != NULL){
    //
    //remove o primeiro char e usa como base para as comparações
    char* t_padrao = NULL;
    int end = 0, colchetes = 0, parenteses = 0, chaves = 0;
    do{
      if(pclone->topo == NULL){
        end = 1; //sinaliza que acabou a string
        break;
      }
      t_padrao = pilha_pop1(pclone); //remove o primeiro char e usa como base
    }while(tipografico(*t_padrao) != 1);
    if(end == 1) break; //Para caso acabar a string.
    //
    //
    int achou_par = 0;
    No* tmp2 = pclone->topo; //procura o proximo char que completa o par tipografico.
    while(tmp2 != NULL){
      char t_muda = tmp2->dado;
      //checa se há pares tipograficos faltando
      if(tipo_completa(*t_padrao, t_muda) == 1){
        if(colchetes == 0 && parenteses == 0 && chaves == 0){
          tmp2->dado = 'x';
          achou_par = 1;
          break;
        }
      }
      //checa se há tipograficos maiores entre um par
      if(precedencia(*t_padrao, t_muda) == 1){
        printf("-> '%s' - Invalido - Ha erros de precedencia entre os sinais!\n\n", x);
        return;
      }else{
        if(t_muda == '{') chaves++;
        if(t_muda == '}') chaves--;
        if(t_muda == '[') colchetes++;
        if(t_muda == ']') colchetes--;
        if(t_muda == '(') parenteses++;
        if(t_muda == ')') parenteses--;
      }
      tmp2 = tmp2->prox;
    }
    //
    //
    if(achou_par == 0){
      printf("-> '%s' - Invalido - Ha sinais tipograficos sem seus pares!\n\n", x);
      pilha_destruir(p);
      pilha_destruir(pclone);
      return;
    }
    tmp = tmp->prox;
  }
  //
  pilha_destruir(pclone);
  pilha_destruir(p);
  printf("-> '%s'  --  Valido!\n\n", x);
}


/**********************************************************************/
/***************************** AUXILIARES *****************************/
int tipografico(char atual){
  if(atual == '{') return 1;
  if(atual == '[') return 1;
  if(atual == '(') return 1;
  if(atual == '}') return 1;
  if(atual == ']') return 1;
  if(atual == ')') return 1;
  return 0;
}

int tipo_completa(char maior, char atual){
  if(maior == '{' && atual == '}') return 1;
  if(maior == '[' && atual == ']') return 1;
  if(maior == '(' && atual == ')') return 1;
  return 0;
}

int precedencia(char maior, char atual){
  if(maior == '['){
    if(atual == '{') return 1;
  }else if(maior == '('){
    if(atual == '{') return 1;
    if(atual == '[') return 1;
  }
  return 0;
}
