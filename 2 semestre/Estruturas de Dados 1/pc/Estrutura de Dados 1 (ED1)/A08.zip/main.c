#include <stdio.h>
#include <stdlib.h>
#include "TAD-vetor.h"

Boolean ehPar(DataType* ptr){
  return (*ptr % 2 == 0 ? true : false);
}
Boolean ehImpar(DataType* ptr){
  return (*ptr % 2 == 0 ? false : true);
}

int compara(DataType* a, DataType* b){
  if(*a > *b) return 1;
  else if (*a < *b) return -1;
  else return 0;
}

int main(){
  Vetor* v = vetor_new();
  vetor_add(v, 5);
  vetor_add(v, 2);
  vetor_add(v, 4);
  vetor_add(v, 1);
  vetor_add(v, 3);

  vetor_genericSort(v, compara);
  vetor_print(v);

  vetor_free(v);
}
