#include <stdio.h>
#include <stdarg.h>

int porta_and(const int numParam, ...) {
    int result;
    va_list lista;
    va_start(lista, numParam);

    for (int i = 0; i < numParam; i++) {
        if(i == 0) {
            if(va_arg(lista, int) == 0)
                result = 0;
            else 
                result = 1;
        }
        else{
            if(result && va_arg(lista, int) == 1)
                result = 1;
            else{
                result = 0;
            }
        }
    }

return result;
}

int porta_or(const int numParam, ...) {
    int result;
    va_list lista;
    va_start(lista, numParam);

    for (int i = 0; i < numParam; i++) {
        if(i == 0) {
            if(va_arg(lista, int) == 0)
                result = 0;
            else 
                result = 1;
        }
        else{
            if(result || va_arg(lista, int) == 1)
                result = 1;
            else{
                result = 0;
            }
        }
    }

return result;
}
int porta_not(int a) {
    if(a == 0)
        a = 1;
    else
        a = 0;

return a;
}

int main(void) {
    int a = 0;
    int b = 0;
    int c = 0;
    int d = 1;

    int A = porta_or(5, porta_and(3, a, porta_not(b), porta_not(d)), porta_and(3, a, porta_not(c), d), porta_and(3, porta_not(a), porta_not(c), porta_not(d)), porta_and(3, porta_not(a), c, d), porta_and(porta_not(a), porta_not(b))); 
    printf("%d ", A);
    int B = porta_or(6, porta_and(2, porta_not(a), porta_not(c)), porta_and(3, porta_not(a), c, d), porta_and(3, porta_not(a), b, c), porta_and(3, a, porta_not(b), porta_not(c)), porta_and(3, a,porta_not(c), d), porta_and(3, a, porta_not(b)));
    printf("%d ", B);
    int C = porta_or(6, porta_and(3, porta_not(b), porta_not(c), porta_not(d)), porta_and(3, a, b, porta_not(c)), porta_and(3, b, porta_not(c), d), porta_and(3, porta_not(a), porta_not(b), c), porta_and(3, porta_not(d), b, c), porta_and(4, a, porta_not(b), c, d));
    printf("%d ", C);   
    int D = porta_or(4, porta_and(3, porta_not(b), porta_not(c), porta_not(d)), porta_and(3, a, b, porta_not(c)), porta_and(2, a, c), porta_and(3, porta_not(a), c, porta_not(d)));
    printf("%d ", D);       
    int E = porta_or(6, porta_and(3, porta_not(a), porta_not(c), porta_not(d)), porta_and(3, b, porta_not(c), porta_not(d)), porta_and(3, porta_not(a), b, porta_not(c)), porta_and(3, a, porta_not(b), porta_not(c)), porta_and(2, a, c), porta_and(3, b, c, porta_not(d)));
    printf("%d ", E);           
    int F =  porta_or(7, porta_and(3, porta_not(b), porta_not(c), porta_not(d)), porta_and(3, a, porta_not(c)), porta_and(3, a, porta_not(b), porta_not(c)), porta_and(3, porta_not(a), b, d), porta_and(2, porta_not(a), c), porta_and(2, b, c), porta_and(c, porta_not(d)));
    printf("%d ", F);              
    int G = porta_or(6, porta_and(2, a, porta_not(b)), porta_and(3, a, b, c), porta_and(3, b, c, porta_not(d)), porta_and(3, b, porta_not(c), d), porta_and(3, porta_not(a), b, porta_not(c)), porta_and(3, porta_not(a), porta_not(b), c)); 
    printf("%d\n", G);              
    
return 0;    
}