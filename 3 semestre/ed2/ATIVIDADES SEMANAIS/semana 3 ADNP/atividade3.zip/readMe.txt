fiz os 2 itens de código no mesmo arquivo .c
