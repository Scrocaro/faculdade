Lista* arquivoParaLista(ALFATrie* dicionario, Lista* palavrasErradas);
void CorrigirOrtografia(ALFATrie* dicionario);