#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "trie.h"

static ALFATrie* AT_Buscar_R(ALFATrie* T, unsigned char *chave, int n, int p)
{
    if(T == NULL)
    {
        return NULL;
    }

    if(p == n)
    {
        return T;
    }

    return AT_Buscar_R(T->filhos[chave[p]-97], chave, n, p+1);  // -97 serve para encontrar a posição no vetor do caractere referente
}

ALFATrie* AT_Buscar(ALFATrie* T, unsigned char *chave)
{
    return AT_Buscar_R(T, chave, strlen(chave), 0);
}

ALFATrie* AT_Criar()
{
    ALFATrie* noh = malloc(sizeof(ALFATrie));

    noh->estado = AT_LIVRE;
    noh->val = 0;
    noh->tam = 0;

    for(int i = 0; i < 26; i++)
    {
        noh->filhos[i] = NULL;
    }

    return noh;
}

static void AT_Inserir_R(ALFATrie **T, unsigned char *chave, int val, int n, int p)
{
    if((*T) == NULL)
    {
        *T = AT_Criar();
    }
    if(p == n-1)
    {
        (*T)->val = val;
        (*T)->estado = AT_OCUPADO;
        return;
    }
    AT_Inserir_R(&(*T)->filhos[chave[p]-97], chave, val, n, p+1);
}

void AT_Inserir(ALFATrie **T, unsigned char *chave, int val)
{
    AT_Inserir_R(T, chave, val, strlen(chave), 0);
    (*T)->tam += 1;
}
/*
static void AT_Remover_R(ALFATrie **T, unsigned char *chave, int n, int p)
{
    if(*T == NULL)
    {
        return;
    }
    if(p == n)
    {
        (*T)->estado = AT_LIVRE;
    }
    else
    {
        AT_Remover_R(&(*T)->filhos[chave[p]], chave, n, p+1);
    }

    if((*T)->estado == AT_LIVRE)
    {
        for(int i = 0; i < 26; i++) 
        {
            if((*T)->filhos[i] != NULL) 
            {
                return;
            }
        }

        free(*T);
        *T = NULL;
    }
}

void AT_Remover(ALFATrie **T, unsigned char *chave)
{
    AT_Remover_R(T, chave, strlen(chave), 0);
}*/

static void AT_Imprimir_R(ALFATrie *T, unsigned char c, int nivel)
{
    if(T == NULL) 
    {
        return;
    }

    for(int i = 0; i < nivel; i++)
    { 
        printf("-");
    }

    char e = (T->estado == 0) ? 'L': 'O';
    printf("(%c) %d (%c)\n", c, T->val, e);

    for(int i = 0; i < 26; i++)
    {
        if(T->filhos[i] != NULL)
        {
            AT_Imprimir_R(T->filhos[i], i+97, nivel+1);
        }
    }
}

void AT_Imprimir(ALFATrie *T)
{
    AT_Imprimir_R(T, 0, 0);
}

int AT_Limpa(ALFATrie *T)
{
    if(T == NULL)
    {
        return 0;
    }

    int tmp = 0;

    for(int i = 0; i < 26; i++)
    {
        if(T->filhos[i] != NULL)
        {
            return AT_Limpa(T->filhos[i]);
        }
        else
        {
            tmp++;
        }
    }

    if(tmp == 26 && T->estado == AT_OCUPADO)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int AT_Tamanho(ALFATrie *T)
{
    return T->tam;
}

void AT_Inserir_I(ALFATrie **T, unsigned char *chave, int val)
{
    if(*T == NULL) 
    {
        *T = AT_Criar();
    }

    int j = strlen(chave);
    int i = 0;
    ALFATrie **tmp = T;

    while(j != 0)
    {
        if((*tmp)->filhos[chave[i]] == NULL)
        {
            (*tmp)->filhos[chave[i]] = AT_Criar();
        }

        tmp = &((*tmp)->filhos[chave[i]]);
        i++;
        j--;
    }

    (*T)->tam++;
    (*tmp)->estado = AT_OCUPADO;
    (*tmp)->val = val;
}

int SubstringCountLenL(char * s, int L)
{
    if(L > strlen(s))
    {
        return 0;
    }

    ALFATrie *subT = NULL;
    char *substring = calloc(L+1, sizeof(char));

    for(int i = 0; i < strlen(s)-1; i++)
    {
        int k = i;
        for(int j = 0; j < L; j++)
        {
            substring[j] = s[i++];
        }

        if(strlen(substring) == L)
        {
            AT_Inserir_I(&subT, substring, i);
        }

        i = k;
    }

    return AT_Tamanho(subT);
}