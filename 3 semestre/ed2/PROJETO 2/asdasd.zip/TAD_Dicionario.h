#pragma once

#include "trie.h"

ALFATrie* ConstruirDicionario(char* arq_lista_palavras);
