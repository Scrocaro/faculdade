#include <stdio.h>
#include <string.h>
#include "TAD_Dicionario.h"

ALFATrie* ConstruirDicionario(char* arq_lista_palavras){
    FILE* f = fopen(arq_lista_palavras, "rb");
    char texto_str[20];
    ALFATrie* T = NULL;
    int i = 1;

    while(fgets(texto_str, 20, f) != NULL){
        strlwr(texto_str);
        AT_Inserir(&T, texto_str, i);
        i++;
    }

    return T;
}

