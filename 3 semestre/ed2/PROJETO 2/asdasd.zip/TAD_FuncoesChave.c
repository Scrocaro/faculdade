
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "TAD_FuncoesChave.h"

static Lista* criarLista()
{
    Lista* list = malloc(sizeof(Lista));
    list->palavra = NULL;
    list->prox = NULL;

    return list;
}

static void atribuirPalavra(Lista* list, char* insercao)
{
    char *chave = calloc(strlen(insercao)+1, sizeof(char));
    strcpy(chave, insercao);
    // free(insercao);

    list->palavra = chave;

    Lista* aux = malloc(sizeof(Lista));
    aux->palavra = NULL;
    aux->prox = NULL;

    list->prox = aux;
}

///////////////////////////// CHAVES COM PREFIXO /////////////////////////////

static void TRIE_ChavesComPrefixo_R(ALFATrie * T, char* prefix, Lista* list)
{   
    char* prefix2 = calloc(47, sizeof(char));
    strcpy(prefix2, prefix);
    char s[2];
    s[1] = 0;


    for(int i = 0; i < 26; i++)
    {  

        if(T->filhos[i] != NULL)
        {
            s[0] = (char)(i+97);
            strcat(prefix2, s);

            if(T->filhos[i]->val != 0)
            {
                printf("inserção %s\n", prefix2);


                atribuirPalavra(list, prefix2);
                // free(prefix2);
            }

            if(list->prox != NULL) 
            {
                TRIE_ChavesComPrefixo_R(T->filhos[i], prefix2, list->prox);
            }
            else
            { 
                TRIE_ChavesComPrefixo_R(T->filhos[i], prefix2, list);
            }
            strcpy(prefix2, prefix);
        }
    }
}

Lista* TRIE_ChavesComPrefixo(ALFATrie *T, char* prefix)
{
    Lista* list = criarLista();

    ALFATrie* r;
    r = AT_Buscar(T, prefix);

    TRIE_ChavesComPrefixo_R(r, prefix, list);

    Lista *aux = list;


    return list;
}


///////////////////////////// CHAVES QUE CASAM /////////////////////////////

/*
4.  Implemente a função TRIE_ChavesQueCasam(Trie *, char* padrao, int n_extras)que retorne a lista dechaves que casam com o padrão padrao. Considere
    o caractere “*” como coringa com até n_extras caracteres extras após o coringa. Por exemplo, para 
    TRIE_ChavesQueCasam (Trie *, char* padrao, int n_extras) com padrao = "ac" e n_extras = 2, sua função deve retornar todos as chaves que casam
    com o padrão "ac**". A lista de chaves deve ser uma implementação adequada de uma TAD lista, com as operações que julgar necessário.
*/

Lista* TRIE_ChavesQueCasam_R(ALFATrie *T, char* padrao, int n_extras, Lista* list, int cont)
{
    char* padraoAux = calloc(47, sizeof(char));
    strcpy(padraoAux, padrao);

    char s[2];
    s[1] = 0;

    for(int i = 0; i < 26; i++)
    {
        if(T->filhos[i] != NULL && cont <= n_extras)
        {
            s[0] = (char)(i+97);
            strcat(padraoAux, s);

            cont++;

            if(T->filhos[i]->val != 0 && cont == n_extras)
            {
                printf("inserção casadas %s\n", padraoAux);
                
                atribuirPalavra(list, padraoAux);
            }

            if(list->prox != NULL) 
            {
                TRIE_ChavesQueCasam_R(T->filhos[i], padraoAux, n_extras, list->prox, cont);
            }
            else
            { 
                TRIE_ChavesQueCasam_R(T->filhos[i], padraoAux, n_extras, list, cont);
            }
            strcpy(padraoAux, padrao);
        }
    }
}


Lista* TRIE_ChavesQueCasam(ALFATrie *T, char* padrao, int n_extras)
{
    Lista* list = criarLista();

    ALFATrie* r;
    r = AT_Buscar(T, padrao);

    TRIE_ChavesQueCasam_R(r, padrao, n_extras, list, 0);
    
    return list;
}