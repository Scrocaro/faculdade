#pragma once

#include "trie.h"

typedef struct Lista{
    char* palavra;
    struct Lista* prox;
}Lista;

Lista* TRIE_ChavesComPrefixo(ALFATrie * T, char* prefix);

Lista* TRIE_ChavesQueCasam(ALFATrie *T, char* padrao, int n_extras);