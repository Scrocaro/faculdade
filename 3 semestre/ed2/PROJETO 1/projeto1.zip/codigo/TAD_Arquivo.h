void Arquivo_Dividir(char* teste, int k, int n_reg_b_e);


void troca(ITEM_VENDA* v, int maior, int i);
int partition(ITEM_VENDA* v, int p, int r);
void quickSort(ITEM_VENDA *v, int e, int d);
